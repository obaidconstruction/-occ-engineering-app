O.C.C Engineering App — لومړنۍ نسخه

دا د Flutter اپلیکیشن د لومړي پړاو سرچینه ده.
اوس پکې شامل دي:
- د O.C.C لوګو او د شرکت رنګونه
- پښتو / English ژبې بدلول
- د انجینري خدماتو Home Screen
- د Camera Measure، 2D CAD، 3D Design، Engineering Calculator،
  Material Estimator او Our Projects لومړني کارتونه
- د Home / Tools / Projects / Profile لاندې مینو

مهم:
دا لومړنی UI prototype دی؛ د CAD رسمولو، 3D ماډل، کامرې اندازه‌ګیري
او محاسبې اصلي انجنونه لا نه دي پکې فعال شوي.

د جوړولو لپاره:
1. Flutter SDK او Android Studio نصب کړئ.
2. دا فولډر خلاص کړئ.
3. په ترمینل کې:
   flutter pub get
   flutter run

د Android APK جوړولو لپاره:
   flutter build apk --release

د خپرولو مخکې باید په واقعي Android موبایلونو کې ازموینه، د ژبو فونټ/RTL
بشپړ تنظیم، محرمیت پالیسي او Play Store اړوند شرطونه بشپړ شي.
