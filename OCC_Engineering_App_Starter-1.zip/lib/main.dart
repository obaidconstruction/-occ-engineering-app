import 'package:flutter/material.dart';

void main() => runApp(const OCCApp());

const navy = Color(0xFF092B49);
const blue = Color(0xFF0789D8);
const paleBlue = Color(0xFFEAF5FD);
const ink = Color(0xFF142C45);

class OCCApp extends StatefulWidget {
  const OCCApp({super.key});
  @override
  State<OCCApp> createState() => _OCCAppState();
}

class _OCCAppState extends State<OCCApp> {
  bool pashto = true;
  int selectedTab = 0;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'O.C.C Engineering',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF6FAFD),
        colorScheme: ColorScheme.fromSeed(seedColor: blue),
        fontFamily: pashto ? null : 'Roboto',
      ),
      home: Directionality(
        textDirection: pashto ? TextDirection.rtl : TextDirection.ltr,
        child: HomeScreen(
          pashto: pashto,
          selectedTab: selectedTab,
          onLanguage: () => setState(() => pashto = !pashto),
          onTab: (v) => setState(() => selectedTab = v),
        ),
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  final bool pashto;
  final int selectedTab;
  final VoidCallback onLanguage;
  final ValueChanged<int> onTab;

  const HomeScreen({
    super.key,
    required this.pashto,
    required this.selectedTab,
    required this.onLanguage,
    required this.onTab,
  });

  String t(String ps, String en) => pashto ? ps : en;

  @override
  Widget build(BuildContext context) {
    final tools = [
      _Tool(Icons.camera_alt_outlined, t('د کامرې اندازه‌ګیري', 'Camera Measure'),
          t('اټکلي اندازه', 'Approximate')),
      _Tool(Icons.architecture_outlined, t('۲D نقشه', '2D CAD Design'),
          t('د نقشې رسمول', 'Draw floor plans')),
      _Tool(Icons.view_in_ar_outlined, t('۳D ډیزاین', '3D Design'),
          t('درې‌بعدي لید', '3D visualization')),
      _Tool(Icons.calculate_outlined, t('انجینري محاسبه', 'Engineering Calculator'),
          t('فورمولونه او واحدونه', 'Formulas & units')),
      _Tool(Icons.construction_outlined, t('د موادو اټکل', 'Material Estimator'),
          t('د ساختماني موادو مقدار', 'Construction quantities')),
      _Tool(Icons.apartment_outlined, t('زموږ پروژې', 'Our Projects'),
          t('بشپړې او روانې پروژې', 'Completed & ongoing')),
    ];

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.white,
        elevation: 0,
        titleSpacing: 16,
        title: Row(
          children: [
            Image.asset('assets/occ_logo.png', width: 43, height: 43,
                fit: BoxFit.contain),
            const SizedBox(width: 9),
            const Expanded(
              child: Text('O.C.C ENGINEERING',
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900,
                      color: navy, letterSpacing: .4)),
            ),
          ],
        ),
        actions: [
          Padding(
            padding: const EdgeInsetsDirectional.only(end: 12),
            child: OutlinedButton(
              onPressed: onLanguage,
              style: OutlinedButton.styleFrom(
                foregroundColor: navy,
                side: const BorderSide(color: Color(0xFFD4E5F2)),
                padding: const EdgeInsets.symmetric(horizontal: 12),
              ),
              child: Text(pashto ? 'EN' : 'پښتو',
                  style: const TextStyle(fontWeight: FontWeight.bold)),
            ),
          )
        ],
      ),
      body: selectedTab == 0
          ? _home(context, tools)
          : _otherTab(context),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedTab,
        onDestinationSelected: onTab,
        backgroundColor: navy,
        indicatorColor: const Color(0xFF164D75),
        labelTextStyle: WidgetStateProperty.all(
          const TextStyle(color: Colors.white, fontSize: 11,
              fontWeight: FontWeight.w600)),
        destinations: [
          NavigationDestination(
              icon: const Icon(Icons.home_outlined, color: Colors.white70),
              selectedIcon: const Icon(Icons.home, color: Colors.white),
              label: t('کور', 'Home')),
          NavigationDestination(
              icon: const Icon(Icons.build_outlined, color: Colors.white70),
              selectedIcon: const Icon(Icons.build, color: Colors.white),
              label: t('وسایل', 'Tools')),
          NavigationDestination(
              icon: const Icon(Icons.folder_open_outlined, color: Colors.white70),
              selectedIcon: const Icon(Icons.folder, color: Colors.white),
              label: t('پروژې', 'Projects')),
          NavigationDestination(
              icon: const Icon(Icons.person_outline, color: Colors.white70),
              selectedIcon: const Icon(Icons.person, color: Colors.white),
              label: t('پروفایل', 'Profile')),
        ],
      ),
    );
  }

  Widget _home(BuildContext context, List<_Tool> tools) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [Color(0xFF0A3558), Color(0xFF087FC2)],
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(t('حلول انجینري', 'Engineering Solutions'),
                  style: const TextStyle(color: Colors.white, fontSize: 25,
                      fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              Text(t('باور • کیفیت • مسلکیتوب',
                      'Trust Quality Professionalism'),
                  style: const TextStyle(color: Colors.white, fontSize: 13,
                      letterSpacing: .5)),
              const SizedBox(height: 17),
              Align(
                alignment: AlignmentDirectional.centerEnd,
                child: Icon(Icons.architecture, size: 62,
                    color: Colors.white.withOpacity(.85)),
              ),
            ],
          ),
        ),
        const SizedBox(height: 22),
        Text(t('خدمات انجینري', 'Engineering Services'),
            style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900,
                color: ink)),
        const SizedBox(height: 12),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: tools.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12,
            childAspectRatio: 1.12,
          ),
          itemBuilder: (context, index) => _toolCard(context, tools[index]),
        ),
        const SizedBox(height: 20),
        Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFE2EDF5)),
          ),
          child: Row(
            children: [
              const Icon(Icons.info_outline, color: blue),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  t('د کامرې اندازه‌ګیري اټکلي ده؛ د مسلکي کار لپاره یې له حقیقي متر سره تایید کړئ.',
                    'Camera measurements are approximate; verify with a physical tape for professional work.'),
                  style: const TextStyle(fontSize: 12, color: ink, height: 1.4),
                ),
              )
            ],
          ),
        ),
      ],
    );
  }

  Widget _toolCard(BuildContext context, _Tool tool) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: () => showDialog<void>(
        context: context,
        builder: (context) => AlertDialog(
          title: Text(tool.title),
          content: Text(t('دا برخه به په راتلونکو پړاوونو کې فعاله شي.',
              'This feature will be implemented in the next development phase.')),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(t('سمه ده', 'OK')),
            )
          ],
        ),
      ),
      child: Ink(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: const Color(0xFFE0ECF5)),
          boxShadow: const [
            BoxShadow(color: Color(0x0D0A3558), blurRadius: 12,
                offset: Offset(0, 4))
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              width: 48, height: 48,
              decoration: BoxDecoration(
                color: paleBlue, borderRadius: BorderRadius.circular(14)),
              child: Icon(tool.icon, color: navy, size: 27),
            ),
            Text(tool.title, maxLines: 2,
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800,
                    color: ink)),
            Text(tool.subtitle, maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 10, color: blue)),
          ],
        ),
      ),
    );
  }

  Widget _otherTab(BuildContext context) {
    final labels = [
      t('کور', 'Home'), t('وسایل', 'Tools'),
      t('پروژې', 'Projects'), t('پروفایل', 'Profile')
    ];
    final icons = [Icons.home, Icons.build, Icons.folder, Icons.person];
    return Center(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(icons[selectedTab], size: 58, color: blue),
        const SizedBox(height: 12),
        Text(labels[selectedTab],
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold,
                color: navy)),
        const SizedBox(height: 6),
        Text(t('دا برخه به په راتلونکي پړاو کې جوړه شي.',
            'This section will be built in a later phase.'),
            style: const TextStyle(color: Colors.black54)),
      ]),
    );
  }
}

class _Tool {
  final IconData icon;
  final String title;
  final String subtitle;
  const _Tool(this.icon, this.title, this.subtitle);
}
