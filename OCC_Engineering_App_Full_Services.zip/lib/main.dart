import 'dart:math' as math;
import 'package:flutter/material.dart';

void main() => runApp(const OCCApp());

const navy = Color(0xFF092B49);
const blue = Color(0xFF0789D8);
const paleBlue = Color(0xFFEAF5FD);
const ink = Color(0xFF142C45);

class OCCApp extends StatefulWidget {
  const OCCApp({super.key});
  @override
  State<OCCApp> createState() => _OCCAppState();
}

class _OCCAppState extends State<OCCApp> {
  bool pashto = true;
  int tab = 0;
  String t(String ps, String en) => pashto ? ps : en;

  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'O.C.C Engineering',
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: blue), scaffoldBackgroundColor: const Color(0xFFF6FAFD)),
    home: Directionality(
      textDirection: pashto ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(backgroundColor: Colors.white, title: Row(children: [
          Image.asset('assets/occ_logo.png', width: 42, height: 42, fit: BoxFit.contain),
          const SizedBox(width: 10), const Expanded(child: Text('O.C.C ENGINEERING', style: TextStyle(color: navy, fontWeight: FontWeight.w900, fontSize: 15))),
        ]), actions: [TextButton(onPressed: () => setState(() => pashto = !pashto), child: Text(pashto ? 'EN' : 'پښتو'))]),
        body: tab == 0 ? _Dashboard(pashto: pashto, open: _open) : _TabPage(tab: tab, pashto: pashto),
        bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v), backgroundColor: navy, indicatorColor: const Color(0xFF164D75), labelTextStyle: WidgetStateProperty.all(const TextStyle(color: Colors.white, fontSize: 11)), destinations: [
          NavigationDestination(icon: const Icon(Icons.home_outlined, color: Colors.white70), selectedIcon: const Icon(Icons.home, color: Colors.white), label: t('کور', 'Home')),
          NavigationDestination(icon: const Icon(Icons.build_outlined, color: Colors.white70), selectedIcon: const Icon(Icons.build, color: Colors.white), label: t('وسایل', 'Tools')),
          NavigationDestination(icon: const Icon(Icons.folder_open, color: Colors.white70), selectedIcon: const Icon(Icons.folder, color: Colors.white), label: t('پروژې', 'Projects')),
          NavigationDestination(icon: const Icon(Icons.person_outline, color: Colors.white70), selectedIcon: const Icon(Icons.person, color: Colors.white), label: t('پروفایل', 'Profile')),
        ]),
      ),
    ),
  );

  void _open(BuildContext context, int index) {
    final pages = <Widget>[
      MaterialCalculator(pashto: pashto),
      FloorPlanPage(pashto: pashto),
      Building3DPage(pashto: pashto),
      EngineeringToolsPage(pashto: pashto),
      CameraMeasurePage(pashto: pashto),
      ProjectsPage(pashto: pashto),
    ];
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => Directionality(textDirection: pashto ? TextDirection.rtl : TextDirection.ltr, child: pages[index])));
  }
}

class _Dashboard extends StatelessWidget {
  final bool pashto;
  final void Function(BuildContext, int) open;
  const _Dashboard({required this.pashto, required this.open});
  String t(String p, String e) => pashto ? p : e;
  @override
  Widget build(BuildContext context) {
    final items = [
      [Icons.construction, t('د موادو محاسبه', 'Material Calculator'), t('کانکریټ، سیمنټ، شګه او جغل', 'Concrete, cement, sand & aggregate')],
      [Icons.architecture, t('۲D نقشه', '2D Floor Plan'), t('د خونو ساده پلان رسمول', 'Draw a simple room layout')],
      [Icons.view_in_ar, t('۳D ډیزاین', '3D Building Preview'), t('د ودانۍ درې‌بعدي مخکتنه', 'Isometric building preview')],
      [Icons.calculate, t('انجینري محاسبه', 'Engineering Tools'), t('مساحت، حجم او واحدونه', 'Area, volume and conversions')],
      [Icons.camera_alt, t('د اندازې وسیله', 'Camera Measure'), t('د اندازې لارښود او ثبت', 'Measurement guide and notes')],
      [Icons.apartment, t('پروژې', 'Projects'), t('د پروژو معلومات او ثبت', 'Project information and entry')],
    ];
    return ListView(padding: const EdgeInsets.all(16), children: [
      Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), gradient: const LinearGradient(colors: [navy, blue], begin: Alignment.topRight, end: Alignment.bottomLeft)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(t('د انجینري حللارې', 'Engineering Solutions'), style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8), Text(t('باور • کیفیت • مسلکیتوب', 'Trust • Quality • Professionalism'), style: const TextStyle(color: Colors.white)),
        const SizedBox(height: 14), const Text('O.C.C', style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
      ])),
      const SizedBox(height: 20), Text(t('زموږ خدمات', 'Our Services'), style: const TextStyle(fontSize: 20, color: ink, fontWeight: FontWeight.w900)),
      const SizedBox(height: 12), GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: items.length, gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.08), itemBuilder: (context, i) {
        final item = items[i];
        return InkWell(borderRadius: BorderRadius.circular(18), onTap: () => open(context, i), child: Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFE0ECF5))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Container(width: 46, height: 46, decoration: BoxDecoration(color: paleBlue, borderRadius: BorderRadius.circular(13)), child: Icon(item[0] as IconData, color: navy, size: 26)), Text(item[1] as String, style: const TextStyle(color: ink, fontWeight: FontWeight.w800, fontSize: 14)), Text(item[2] as String, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: blue, fontSize: 11))])));
      }),
      const SizedBox(height: 16), _note(t('یادونه: د اپ محاسبې اټکلي دي؛ د عملي ساختماني کار لپاره یې مسلکي انجینر تایید کړي.', 'Note: App calculations are estimates and must be checked by a qualified engineer before construction.')),
    ]);
  }
}

class MaterialCalculator extends StatefulWidget {
  final bool pashto;
  const MaterialCalculator({super.key, required this.pashto});
  @override
  State<MaterialCalculator> createState() => _MaterialCalculatorState();
}
class _MaterialCalculatorState extends State<MaterialCalculator> {
  final l = TextEditingController(), w = TextEditingController(), h = TextEditingController();
  String ratio = '1:2:4';
  Map<String, double>? result;
  String t(String p, String e) => widget.pashto ? p : e;
  @override
  void dispose() { l.dispose(); w.dispose(); h.dispose(); super.dispose(); }
  void calculate() {
    final a = double.tryParse(l.text.replaceAll(',', '.'));
    final b = double.tryParse(w.text.replaceAll(',', '.'));
    final c = double.tryParse(h.text.replaceAll(',', '.'));
    if (a == null || b == null || c == null || a <= 0 || b <= 0 || c <= 0) { _message(context, t('درې واړه مثبتې اندازې ولیکئ.', 'Enter three positive dimensions.')); return; }
    final parts = ratio.split(':').map(double.parse).toList();
    final wet = a*b*c, dry = wet*1.54, total = parts.reduce((x,y)=>x+y);
    setState(() => result = {'volume':wet, 'bags':dry*parts[0]/total/0.0347, 'sand':dry*parts[1]/total, 'stone':dry*parts[2]/total});
  }
  @override
  Widget build(BuildContext context) => _pageScaffold(context, t('د ساختماني موادو محاسبه', 'Material Calculator'), ListView(padding: const EdgeInsets.all(16), children: [
    _note(t('اوږدوالی، پلنوالی او ضخامت په متر ولیکئ. پایله د ټاکلي مخلوط نسبت له مخې اټکل کېږي.', 'Enter length, width and depth in metres. Results are estimated from the selected nominal mix ratio.')),
    const SizedBox(height: 12), _field(l,t('اوږدوالی (متر)', 'Length (m)')), _field(w,t('پلنوالی (متر)', 'Width (m)')), _field(h,t('ضخامت / لوړوالی (متر)', 'Depth / height (m)')),
    DropdownButtonFormField<String>(value: ratio, decoration: InputDecoration(labelText: t('د کانکریټ نسبت', 'Concrete mix ratio'), border: const OutlineInputBorder()), items: const [DropdownMenuItem(value:'1:2:4',child:Text('1 : 2 : 4')),DropdownMenuItem(value:'1:1.5:3',child:Text('1 : 1.5 : 3'))], onChanged:(v)=>setState(()=>ratio=v??'1:2:4')),
    const SizedBox(height: 12), FilledButton.icon(onPressed: calculate, icon: const Icon(Icons.calculate), label: Text(t('محاسبه وکړه','Calculate'))),
    if (result != null) ...[
      const SizedBox(height: 16), _result(t('د محاسبې پایله','Calculation result'), [
        '${t('د کانکریټ حجم','Wet concrete volume')}: ${result!['volume']!.toStringAsFixed(2)} m³',
        '${t('د سیمنټو بوجۍ (۵۰ کیلو)','Cement bags (50 kg)')}: ${result!['bags']!.toStringAsFixed(1)}',
        '${t('شګه','Sand')}: ${result!['sand']!.toStringAsFixed(2)} m³',
        '${t('جغل','Aggregate')}: ${result!['stone']!.toStringAsFixed(2)} m³',
      ]),
      _note(t('دا د موادو لومړنی اټکل دی. د رطوبت، د جغل د اندازې، ضایعاتو، د موادو کثافت او د طرحې له مخې مقدار بدل شي. د جوړښت لپاره د انجینر منظور شوی mix design وکاروئ.', 'Preliminary estimate only. Moisture, aggregate grading, waste, density and approved mix design change quantities. Use an engineer-approved mix design for structural concrete.')),
    ],
  ]));
}

class FloorPlanPage extends StatefulWidget { final bool pashto; const FloorPlanPage({super.key,required this.pashto}); @override State<FloorPlanPage> createState()=>_FloorPlanPageState(); }
class _FloorPlanPageState extends State<FloorPlanPage> {
  final x=TextEditingController(text:'4'), y=TextEditingController(text:'3'); final List<Size> rooms=[];
  String t(String p,String e)=>widget.pashto?p:e;
  @override void dispose(){x.dispose();y.dispose();super.dispose();}
  void add(){final a=double.tryParse(x.text),b=double.tryParse(y.text);if(a==null||b==null||a<=0||b<=0||a>20||b>20){_message(context,t('اندازې له ۰ څخه تر ۲۰ مترو پورې ولیکئ.','Enter dimensions between 0 and 20 metres.'));return;}setState(()=>rooms.add(Size(a,b)));}
  @override Widget build(BuildContext context)=>_pageScaffold(context,t('۲D د نقشې رسمول','2D Floor Plan'),ListView(padding:const EdgeInsets.all(16),children:[_note(t('د خونې اوږدوالی او پلنوالی ولیکئ او «خونه اضافه کړه» ووهئ. دا ساده ابتدایي پلان جوړوونکی دی، د ساختماني نقشې بدیل نه دی.','Enter room length and width, then add the room. This is a basic concept planner, not a construction drawing.')),_field(x,t('اوږدوالی (متر)','Length (m)'),keyboard:TextInputType.number),_field(y,t('پلنوالی (متر)','Width (m)'),keyboard:TextInputType.number),FilledButton.icon(onPressed:add,icon:const Icon(Icons.add),label:Text(t('خونه اضافه کړه','Add room'))),Text('${t('د خونو شمېر','Rooms')}: ${rooms.length}',style:const TextStyle(fontWeight:FontWeight.bold)),Container(height:300,margin:const EdgeInsets.symmetric(vertical:12),decoration:BoxDecoration(color:Colors.white,border:Border.all(color:const Color(0xFFD8E7F2)),borderRadius:BorderRadius.circular(14)),child:CustomPaint(painter:PlanPainter(rooms),child:const SizedBox.expand())),if(rooms.isNotEmpty)OutlinedButton(onPressed:()=>setState(rooms.clear),child:Text(t('ټولې خونې پاکې کړه','Clear plan')))]));
}
class PlanPainter extends CustomPainter { final List<Size> rooms; PlanPainter(List<Size> rooms): rooms=List<Size>.of(rooms); @override void paint(Canvas canvas,Size size){final grid=Paint()..color=const Color(0xFFE8EFF5)..strokeWidth=.7;for(double x=0;x<size.width;x+=20){canvas.drawLine(Offset(x,0),Offset(x,size.height),grid);}for(double y=0;y<size.height;y+=20){canvas.drawLine(Offset(0,y),Offset(size.width,y),grid);}double left=18,top=18;final scale=math.min((size.width-36)/20,(size.height-36)/20);for(int i=0;i<rooms.length;i++){final r=rooms[i];final rect=Rect.fromLTWH(left,top,r.width*scale,r.height*scale);canvas.drawRect(rect,Paint()..color=blue.withOpacity(.12)..style=PaintingStyle.fill);canvas.drawRect(rect,Paint()..color=navy..strokeWidth=2..style=PaintingStyle.stroke);final tp=TextPainter(text:TextSpan(text:'${r.width.toStringAsFixed(1)} × ${r.height.toStringAsFixed(1)} m',style:const TextStyle(color:navy,fontSize:10,fontWeight:FontWeight.bold)),textDirection:TextDirection.ltr)..layout(maxWidth:rect.width);tp.paint(canvas,Offset(rect.left+3,rect.top+3));left+=r.width*scale+12;if(left+r.width*scale>size.width){left=18;top+=r.height*scale+14;}}} @override bool shouldRepaint(covariant PlanPainter old)=>old.rooms.length!=rooms.length||old.rooms!=rooms;}

class Building3DPage extends StatefulWidget {final bool pashto;const Building3DPage({super.key,required this.pashto});@override State<Building3DPage> createState()=>_Building3DPageState();}
class _Building3DPageState extends State<Building3DPage>{int floors=2;String t(String p,String e)=>widget.pashto?p:e;@override Widget build(BuildContext context)=>_pageScaffold(context,t('۳D د ودانۍ مخکتنه','3D Building Preview'),ListView(padding:const EdgeInsets.all(16),children:[_note(t('د پوړونو شمېر بدل کړئ. دا ساده ایزومیټریک تصور دی، دقیق معماري 3D ماډل یا ساختماني نقشه نه ده.','Change the number of floors. This is a simple isometric concept preview, not a precise architectural 3D model or construction drawing.')),Row(children:[Text(t('پوړونه','Floors')),Expanded(child:Slider(value:floors.toDouble(),min:1,max:5,divisions:4,label:'$floors',onChanged:(v)=>setState(()=>floors=v.round()))),Text('$floors')]),Container(height:360,decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(16),border:Border.all(color:const Color(0xFFDDEAF3))),child:CustomPaint(painter:BuildingPainter(floors),child:const SizedBox.expand()))]));}}
class BuildingPainter extends CustomPainter{final int floors;BuildingPainter(this.floors);@override void paint(Canvas c,Size s){final ox=s.width*.48,oy=s.height*.72,w=s.width*.34,d=s.width*.18,fh=s.height*.105;final side=Path()..moveTo(ox,oy)..lineTo(ox+d,oy-d*.45)..lineTo(ox+d,oy-d*.45-floors*fh)..lineTo(ox,oy-floors*fh)..close();final front=Path()..moveTo(ox,oy)..lineTo(ox-w,oy-d*.35)..lineTo(ox-w,oy-d*.35-floors*fh)..lineTo(ox,oy-floors*fh)..close();c.drawPath(front,Paint()..color=const Color(0xFFB9DDF2));c.drawPath(side,Paint()..color=const Color(0xFF75B7DF));final roof=Path()..moveTo(ox,oy-floors*fh)..lineTo(ox-w,oy-d*.35-floors*fh)..lineTo(ox-w+d,oy-d*.8-floors*fh)..lineTo(ox+d,oy-d*.45-floors*fh)..close();c.drawPath(roof,Paint()..color=navy);final line=Paint()..color=Colors.white..strokeWidth=2;for(int i=1;i<floors;i++){final y=oy-i*fh;c.drawLine(Offset(ox,y),Offset(ox-w,y-d*.35),line);c.drawLine(Offset(ox,y),Offset(ox+d,y-d*.45),line);}for(int i=0;i<floors;i++){final y=oy-i*fh-fh*.55;for(int j=0;j<2;j++){final x=ox-w*.75+j*w*.38;c.drawRect(Rect.fromLTWH(x,y,16,22),Paint()..color=Colors.white);}}c.drawLine(Offset(ox,oy),Offset(ox,oy-floors*fh),Paint()..color=navy..strokeWidth=2);} @override bool shouldRepaint(covariant BuildingPainter old)=>old.floors!=floors;}

class EngineeringToolsPage extends StatefulWidget{final bool pashto;const EngineeringToolsPage({super.key,required this.pashto});@override State<EngineeringToolsPage> createState()=>_EngineeringToolsPageState();}
class _EngineeringToolsPageState extends State<EngineeringToolsPage>{final a=TextEditingController(),b=TextEditingController(),h=TextEditingController();String mode='area';double? answer;String t(String p,String e)=>widget.pashto?p:e;@override void dispose(){a.dispose();b.dispose();h.dispose();super.dispose();}void calc(){final x=double.tryParse(a.text),y=double.tryParse(b.text),z=double.tryParse(h.text);if(x==null||y==null||(mode=='volume'&&(z==null||z<=0))||x<=0||y<=0){_message(context,t('سم عددونه ولیکئ.','Enter valid positive numbers.'));return;}setState(()=>answer=mode=='area'?x*y:mode=='perimeter'?2*(x+y):x*y*z!);} @override Widget build(BuildContext context)=>_pageScaffold(context,t('انجینري محاسبې','Engineering Calculator'),ListView(padding:const EdgeInsets.all(16),children:[DropdownButtonFormField<String>(value:mode,decoration:InputDecoration(labelText:t('د محاسبې ډول','Calculation type'),border:const OutlineInputBorder()),items:[DropdownMenuItem(value:'area',child:Text(t('مستطیل مساحت','Rectangle area'))),DropdownMenuItem(value:'perimeter',child:Text(t('مستطیل محیط','Rectangle perimeter'))),DropdownMenuItem(value:'volume',child:Text(t('مستطیل حجم','Rectangular volume')))],onChanged:(v){setState((){mode=v??'area';answer=null;});}),_field(a,t('اوږدوالی (m)','Length (m)'),keyboard:TextInputType.number),_field(b,t('پلنوالی (m)','Width (m)'),keyboard:TextInputType.number),if(mode=='volume')_field(h,t('لوړوالی (m)','Height (m)'),keyboard:TextInputType.number),FilledButton(onPressed:calc,child:Text(t('محاسبه','Calculate'))),if(answer!=null)_result(t('پایله','Result'),['${answer!.toStringAsFixed(3)} ${mode=='area'?'m²':mode=='volume'?'m³':'m'}']),_note(t('دا عمومي هندسي محاسبې دي؛ د بار، سیخ‌بندۍ او ساختماني ډیزاین تصدیق نه کوي.','These are basic geometry calculations; they do not verify loads, reinforcement or structural design.'))]));}}

class CameraMeasurePage extends StatelessWidget{final bool pashto;const CameraMeasurePage({super.key,required this.pashto});String t(String p,String e)=>pashto?p:e;@override Widget build(BuildContext context)=>_pageScaffold(context,t('د اندازې وسیله','Measurement Tool'),ListView(padding:const EdgeInsets.all(16),children:[_note(t('په دې نسخه کې ژوندۍ کامره او AR اندازه‌ګیري لا نه ده فعاله. د موبایل له کامرې اخیستل شوی عکس له معلومې مرجع اندازې پرته دقیق اندازه نه شي ورکولای.','Live camera and AR measurement are not enabled in this version. A camera image cannot provide reliable dimensions without a known reference scale.')),_result(t('د خوندي اندازه‌ګیرۍ لارښود','Measurement guide'),[t('۱. د متر په وسیله حقیقي اوږدوالی ثبت کړئ.','1. Record the actual length with a tape measure.'),t('۲. واحد په متر یا سانتي‌متر ولیکئ.','2. Note the unit in metres or centimetres.'),t('۳. مهمې اندازې دوه ځله تایید کړئ.','3. Verify important dimensions twice.')]) ]));}

class ProjectsPage extends StatefulWidget{final bool pashto;const ProjectsPage({super.key,required this.pashto});@override State<ProjectsPage> createState()=>_ProjectsPageState();}
class _ProjectsPageState extends State<ProjectsPage>{final name=TextEditingController(),details=TextEditingController();final List<String> projects=[];String t(String p,String e)=>widget.pashto?p:e;@override void dispose(){name.dispose();details.dispose();super.dispose();}@override Widget build(BuildContext context)=>_pageScaffold(context,t('د پروژو ثبت','Project Register'),ListView(padding:const EdgeInsets.all(16),children:[_field(name,t('د پروژې نوم','Project name')), _field(details,t('لنډ معلومات','Short description')),FilledButton.icon(onPressed:(){if(name.text.trim().isEmpty){_message(context,t('د پروژې نوم ولیکئ.','Enter a project name.'));return;}setState(()=>projects.add('${name.text.trim()} — ${details.text.trim()}'));name.clear();details.clear();},icon:const Icon(Icons.add),label:Text(t('پروژه اضافه کړه','Add project'))),const SizedBox(height:12),if(projects.isEmpty)_note(t('تر اوسه پروژه نه ده ثبت شوې.','No projects have been added yet.')),for(final p in projects)Card(child:ListTile(leading:const Icon(Icons.apartment,color:blue),title:Text(p),trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:()=>setState(()=>projects.remove(p))))),_note(t('دا معلومات د اپ د اوسني چلولو پر مهال ساتل کېږي؛ دایمي آنلاین ذخیره نه ده.','Entries are held during this app session only; they are not stored online permanently.'))]));}}

class _TabPage extends StatelessWidget{final int tab;final bool pashto;const _TabPage({required this.tab,required this.pashto});@override Widget build(BuildContext context){final p=pashto;final title=tab==1?(p?'وسایل':'Tools'):tab==2?(p?'پروژې':'Projects'):(p?'پروفایل':'Profile');return Center(child:Text(title,style:const TextStyle(fontSize:22,color:navy,fontWeight:FontWeight.bold)));}}

Widget _pageScaffold(BuildContext context,String title,Widget body)=>Scaffold(appBar:AppBar(title:Text(title),backgroundColor:Colors.white,foregroundColor:navy),body:body);
Widget _field(TextEditingController c,String label,{TextInputType keyboard=const TextInputType.numberWithOptions(decimal:true)})=>Padding(padding:const EdgeInsets.only(bottom:12),child:TextField(controller:c,keyboardType:keyboard,decoration:InputDecoration(labelText:label,border:const OutlineInputBorder(),filled:true,fillColor:Colors.white)));
Widget _note(String text)=>Container(padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:paleBlue,borderRadius:BorderRadius.circular(14)),child:Text(text,style:const TextStyle(color:ink,height:1.45,fontSize:13)));
Widget _result(String title,List<String> lines)=>Container(margin:const EdgeInsets.symmetric(vertical:10),padding:const EdgeInsets.all(15),decoration:BoxDecoration(color:Colors.white,border:Border.all(color:const Color(0xFFDDEAF3)),borderRadius:BorderRadius.circular(14)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(color:navy,fontWeight:FontWeight.w900,fontSize:17)),const SizedBox(height:8),for(final line in lines)Padding(padding:const EdgeInsets.symmetric(vertical:4),child:Text(line,style:const TextStyle(color:ink,fontSize:14)))]));
void _message(BuildContext context,String text)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(text)));
